-- ================================================================
-- QUERY 1: COMPLETE BOOKING DETAILS
-- Shows comprehensive booking information including customer, 
-- package, hotel, and flight details
-- ================================================================

SELECT 
    b.booking_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.email AS customer_email,
    p.package_name,
    d.destination_name,
    d.country,
    h.hotel_name,
    ph.nights AS hotel_nights,
    f.flight_number,
    f.airline,
    bf.seat_class,
    b.travel_date,
    b.return_date,
    b.total_amount AS total_cost,
    b.booking_status,
    b.payment_status
FROM Booking b
JOIN Customer c ON b.customer_id = c.customer_id
JOIN Booking_Package bp ON b.booking_id = bp.booking_id
JOIN Package p ON bp.package_id = p.package_id
JOIN Destination d ON p.destination_id = d.destination_id
JOIN Package_Hotel ph ON p.package_id = ph.package_id
JOIN Hotel h ON ph.hotel_id = h.hotel_id
JOIN Booking_Flight bf ON b.booking_id = bf.booking_id
JOIN Flight f ON bf.flight_id = f.flight_id
WHERE b.booking_status = 'Confirmed'
ORDER BY b.booking_date DESC
LIMIT 10;

-- ================================================================
-- WHAT THIS QUERY DOES:
-- - Demonstrates JOINs across multiple tables (8 tables joined)
-- - Shows complete booking information in one view
-- - Combines customer, booking, package, destination, hotel, and flight data
-- - Filters for confirmed bookings only
-- - Orders by most recent bookings first
-- - Limits to top 10 results
-- ================================================================
