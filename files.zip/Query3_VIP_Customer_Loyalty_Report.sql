-- ================================================================
-- QUERY 3: VIP CUSTOMER REPORT WITH LOYALTY ANALYSIS
-- Identifies top customers with booking history and loyalty status
-- Customer Relationship Management (CRM) query
-- ================================================================

SELECT 
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.email,
    c.loyalty_points,
    CASE 
        WHEN c.loyalty_points >= 400 THEN 'Platinum'
        WHEN c.loyalty_points >= 250 THEN 'Gold'
        WHEN c.loyalty_points >= 150 THEN 'Silver'
        ELSE 'Bronze'
    END AS loyalty_tier,
    COUNT(DISTINCT b.booking_id) AS total_bookings,
    SUM(b.total_amount) AS lifetime_value,
    ROUND(AVG(b.total_amount), 2) AS avg_booking_value,
    MAX(b.booking_date) AS last_booking_date,
    COUNT(DISTINCT r.review_id) AS reviews_written,
    ROUND(AVG(r.rating), 2) AS avg_review_rating
FROM Customer c
LEFT JOIN Booking b ON c.customer_id = b.customer_id AND b.payment_status = 'Paid'
LEFT JOIN Review r ON c.customer_id = r.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name, c.email, c.loyalty_points
HAVING total_bookings > 0
ORDER BY lifetime_value DESC, loyalty_points DESC
LIMIT 15;

-- ================================================================
-- WHAT THIS QUERY DOES:
-- - Demonstrates CASE statement for business logic (loyalty tiers)
-- - Uses multiple aggregation functions (COUNT, SUM, AVG, MAX)
-- - Calculates customer lifetime value
-- - Identifies VIP customers for targeted marketing
-- - Shows customer engagement through reviews
-- - Uses LEFT JOIN to include customers without reviews
-- - Groups by customer and ranks by spending
-- - Useful for loyalty programs and marketing campaigns
-- ================================================================

-- ================================================================
-- LOYALTY TIER BREAKDOWN:
-- - Platinum: 400+ points (top spenders)
-- - Gold:     250-399 points (frequent travelers)
-- - Silver:   150-249 points (regular customers)
-- - Bronze:   0-149 points (new/occasional customers)
-- ================================================================

-- ================================================================
-- SAMPLE OUTPUT:
-- customer_id | customer_name  | email              | loyalty_points | loyalty_tier | total_bookings | lifetime_value | avg_booking_value | last_booking_date   | reviews_written | avg_review_rating
-- ------------|----------------|--------------------| ---------------|--------------|----------------|----------------|-------------------|---------------------|-----------------|------------------
-- 1           | John Smith     | john.smith@...     | 500            | Platinum     | 8              | 24000.00       | 3000.00           | 2024-12-15 14:30:00 | 5               | 4.8
-- 11          | Daniel Roberts | daniel.r@...       | 410            | Platinum     | 6              | 18000.00       | 3000.00           | 2024-12-10 10:20:00 | 4               | 4.5
-- 3           | Michael Williams| michael.w@...     | 420            | Platinum     | 7              | 21000.00       | 3000.00           | 2024-11-28 16:45:00 | 6               | 4.9
-- ================================================================
