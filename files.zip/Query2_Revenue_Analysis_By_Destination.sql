-- ================================================================
-- QUERY 2: REVENUE ANALYSIS BY DESTINATION
-- Analyzes revenue and customer satisfaction by destination
-- Business intelligence query for management reporting
-- ================================================================

SELECT 
    d.destination_name,
    d.country,
    COUNT(DISTINCT b.booking_id) AS total_bookings,
    SUM(b.total_amount) AS total_revenue,
    ROUND(AVG(b.total_amount), 2) AS avg_booking_value,
    ROUND(AVG(p.rating), 2) AS avg_package_rating,
    COUNT(DISTINCT r.review_id) AS total_reviews
FROM Destination d
JOIN Package p ON d.destination_id = p.destination_id
JOIN Booking_Package bp ON p.package_id = bp.package_id
JOIN Booking b ON bp.booking_id = b.booking_id
LEFT JOIN Review r ON p.package_id = r.package_id
WHERE b.payment_status = 'Paid'
GROUP BY d.destination_id, d.destination_name, d.country
HAVING total_bookings > 0
ORDER BY total_revenue DESC
LIMIT 10;

-- ================================================================
-- WHAT THIS QUERY DOES:
-- - Demonstrates GROUP BY and aggregation functions
-- - Calculates total bookings and revenue per destination
-- - Computes average booking value and package ratings
-- - Uses LEFT JOIN to include destinations without reviews
-- - Filters for paid bookings only
-- - Shows top 10 most profitable destinations
-- - Useful for business decision-making and marketing strategy
-- ================================================================

-- ================================================================
-- SAMPLE OUTPUT:
-- destination_name       | country     | total_bookings | total_revenue | avg_booking_value | avg_package_rating | total_reviews
-- -----------------------|-------------|----------------|---------------|-------------------|--------------------|--------------
-- Santorini Paradise     | Greece      | 15             | 45000.00      | 3000.00           | 4.8                | 12
-- Maldives Escape        | Maldives    | 12             | 50400.00      | 4200.00           | 4.9                | 10
-- Dubai Luxury           | UAE         | 18             | 63000.00      | 3500.00           | 5.0                | 15
-- ================================================================
